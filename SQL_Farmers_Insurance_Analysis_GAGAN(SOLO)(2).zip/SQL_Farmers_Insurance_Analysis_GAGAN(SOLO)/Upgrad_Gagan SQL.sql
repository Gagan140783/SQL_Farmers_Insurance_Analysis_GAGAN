-- =========================================================================================================================================
-- Group Name        : Gagan (Solo Submission)
-- Assignment Title  : SQL Assignment - Farmers Insurance Analysis
-- Assignment ID     : SQL/02
-- Submitted On      : [11/5/2025]
-- =========================================================================================================================================
SET GLOBAL local_infile=1;
-- Loading a table is to create the schema first and then use the table data import wizard in MySQL Workbench
CREATE DATABASE pmfby_db;
## Verifying the table exists and checking right schema
USE pmfby_db;   
##Fixing the “Table definition has changed” issue
FLUSH TABLES;          -- clearing any lingering metadata locks / 
-- Verify table structure and data
SHOW TABLES;
DESCRIBE data_clean2;
-- Verifying original table row count
RENAME TABLE data_clean2 TO data;
SELECT COUNT(*) FROM data;
############################################################################################### ###############################################################################################################################################################################3
-- Q1. Extract distinct state names from the dataset to understand the data coverage across regions.
-- [2 Marks]
-- Approach: 
-- USING SELECT DISTINCT to eliminate duplicate srcStateName values
-- ORDER BY to sort alphabetically
-- This simple query ensures clarity and avoids redundant data
SELECT DISTINCT srcStateName
FROM data
ORDER BY srcStateName;
############################################################################################### ###############################################################################################################################################################################
-- Q2. Summarize the number of farmers and total insurance coverage per state, prioritizing states with higher farmer count.
--     and the sum insured (SumInsured) for each state (srcStateName), ordered by TotalFarmersCovered in descending order.
-- [3 Marks]
-- Approach: 
-- USING GROUP BY to aggregate by srcStateName
-- SUMING to calculate totals
-- COALESCE to handle NULL values (returning 0 if NULL)
-- ORDER BY sorts the results for better readability
SELECT srcStateName,
       COALESCE(SUM(TotalFarmersCovered), 0) AS total_farmers_covered,
       COALESCE(SUM(SumInsured), 0) AS total_sum_insured
FROM data
GROUP BY srcStateName
ORDER BY total_farmers_covered DESC;

############################################################################################### ###############################################################################################################################################################################
-- Q3. Filter and return records corresponding to the policy year 2020 for targeted year-wise analysis.
-- [2 Marks]
-- Approach: 
-- Since Year is a VARCHAR 
-- USING RIGHT(Year, 4) to extract the last 4 characters ('2020')
-- Filtering with WHERE
-- SELECT * returns all columns for the matching rows
SELECT * FROM data
WHERE RIGHT(Year, 4) = '2020';
############################################################################################### ###############################################################################################################################################################################
-- Q4. Identify rows from Himachal Pradesh where rural population exceeds one million.
--     and the srcStateName is 'HIMACHAL PRADESH'.
-- [3 Marks]
-- Approach: 
-- USING WHERE to Filtering by srcStateName and TotalPopulationRural (> 1000000)
-- SELECT * returns all columns for matching records
-- Assumes TotalPopulationRural is numeric
SELECT * FROM data
WHERE srcStateName = 'HIMACHAL PRADESH'
  AND TotalPopulationRural > 1000000;
  ############################################################################################### ###############################################################################################################################################################################3
  -- Q5. Aggregate premium amounts per district for 2018 and list them in ascending order of contribution.
--     for each district in the year 2018, and display the results ordered by
--     FarmersPremiumAmount in ascending order.
-- [5 Marks]
-- Approach: 
-- Filtering for 2018 USING RIGHT(Year, 4)
-- GROUP BY srcStateName and srcDistrictName to aggregate
-- SUMING with COALESCE to handle NULLs
-- ORDER BY sorts results for clarity
SELECT srcStateName,
       srcDistrictName,
       COALESCE(SUM(FarmersPremiumAmount), 0) AS total_farmers_premium
FROM data
WHERE RIGHT(Year, 4) = '2018'
GROUP BY srcStateName, srcDistrictName
ORDER BY total_farmers_premium ASC;
############################################################################################### #############################################################################
-- Q6. Fetch total farmers covered and total premium paid for states in 2018 with insured land exceeding 5 hectares.
--     premiums (GrossPremiumAmountToBePaid) for each state (srcStateName) where the
--     insured land area (InsuredLandArea) is greater than 5.0 and the Year is 2018.
-- [5 Marks]
-- Approach: 
-- Filtering for 2018 and InsuredLandArea > 5.0
-- GROUP BY srcStateName
-- USING SUMING with COALESCE for aggregates
-- ORDER BY srcStateName ensures alphabetical sorting
SELECT 
    srcStateName,
    COALESCE(SUM(TotalFarmersCovered), 0) AS total_farmers_covered,
    COALESCE(SUM(GrossPremiumAmountToBePaid), 0) AS total_gross_premium
FROM data
WHERE RIGHT(Year, 4) = '2018'
  AND InsuredLandArea > 5.0
GROUP BY srcStateName
ORDER BY srcStateName;  
############################################################################################### #############################################################################
-- SECTION 3.
-- Aggregation (GROUP BY) [10 marks]

-- Q7. Compute the yearly average of insured land to identify any variation across different years.
-- [3 Marks]
-- Approach: 
-- Use srcYear directly as it’s an integer year value
-- GROUP BY srcYear to calculate AVG(InsuredLandArea)
-- ORDER BY srcYear for chronological sorting
-- AVG automatically skips NULL values
SELECT srcYear AS policy_year,
       AVG(InsuredLandArea) AS avg_insured_land_area
FROM data
GROUP BY srcYear
ORDER BY srcYear;
############################################################################################### #############################################################################
-- Q8. Determine farmer coverage per district where insurance units reported are greater than zero.
--     district (srcDistrictName) where Insurance units is greater than 0.
-- [3 Marks]
-- Approach: 
-- Filtering with WHERE InsuranceUnits > 0
-- GROUP BY srcStateName and srcDistrictName
-- SUMING with COALESCE for aggregation
-- ORDER BY ensures sorted output
SELECT
    srcStateName,
    srcDistrictName,
    COALESCE(SUM(TotalFarmersCovered),0) AS total_farmers_covered
FROM data
WHERE `Insurance units` > 0
GROUP BY srcStateName, srcDistrictName
ORDER BY srcStateName, srcDistrictName;
############################################################################################### #############################################################################
-- Q9. Aggregate state-wise premium and farmer coverage, considering only entries with substantial insured amounts.
--     StatePremiumAmount, GOVPremiumAmount) and the total number of farmers covered
--     (TotalFarmersCovered). Only include records where the sum insured (SumInsured) is
--     greater than 500,000 (remember to check for scaling).
-- [4 Marks]
DESCRIBE data;
-- Approach: 
-- Filtering with WHERE SumInsured > 500000
-- GROUP BY srcStateName
-- USING COALESCE treat NULL values as 0 in the aggregation functions
-- USING SUMING with COALESCE for multiple aggregates
-- ORDER BY srcStateName for readability
SELECT 
    srcstatename AS state_name,
    SUM(COALESCE(farmerspremiumamount, 0)) AS total_farmers_premium,
    SUM(COALESCE(statepremiumamount, 0)) AS total_state_premium,
    SUM(COALESCE(govpremiumamount, 0)) AS total_gov_premium,
    SUM(COALESCE(totalfarmerscovered, 0)) AS total_farmers_covered,
    SUM(COALESCE(suminsured, 0)) AS total_suminsured
FROM data
GROUP BY srcstatename
HAVING total_suminsured > 500000
ORDER BY total_farmers_covered DESC;

############################################################################################### #############################################################################
-- Q10. Identify the top five districts with highest population figures in 2020.
--      in the year 2020.
-- [2 Marks]
-- Approach: 
-- Filtering for 2020 USING RIGHT(Year, 4)
-- ORDER BY TotalPopulation DESC to sort
-- LIMIT 5 to get the top 5
-- SELECT specific columns for clarity
SELECT srcStateName,
       srcDistrictName,
       TotalPopulation
FROM data
WHERE RIGHT(Year, 4) = '2020'
ORDER BY TotalPopulation DESC
LIMIT 5;

############################################################################################### #############################################################################
-- Q11. Fetch 10 districts with lowest positive farmer premiums, ordered by insured amount and premium paid.
--      with the lowest non-zero FarmersPremiumAmount, ordered by insured sum and then
--      the FarmersPremiumAmount.
-- [3 Marks]
-- Approach: 
-- Filtering with WHERE FarmersPremiumAmount > 0
-- ORDER BY SumInsured ASC
-- ORDER BY FarmersPremiumAmount ASC for dual sorting
-- LIMIT 10 for the top 10 results
SELECT srcStateName,
       srcDistrictName,
       SumInsured,
       FarmersPremiumAmount
FROM data
WHERE FarmersPremiumAmount > 0
ORDER BY SumInsured ASC, FarmersPremiumAmount ASC
LIMIT 10;

############################################################################################### #############################################################################

-- Q12. Calculate the ratio of insured farmers to total population and return top three states with the highest values.
--      ratio of insured farmers (TotalFarmersCovered) to the total population
--      (TotalPopulation) is highest. Sort the results by the ratio in descending order.
-- [5 Marks]
-- Approach: 
-- Calculate ratio USING CASE to handle NULLs and division by zero (TotalFarmersCovered / TotalPopulation)
--  USING CASE expression to safely handle division by zero and NULL values in TotalPopulation.
-- Filtering out invalid populations
-- ORDER BY ratio DESC
-- LIMIT 3
SELECT srcStateName,
       RIGHT(Year, 4) AS policy_year,
       TotalFarmersCovered,
       TotalPopulation,
       CASE
           WHEN TotalPopulation IS NULL OR TotalPopulation <= 0 THEN 0
           ELSE COALESCE(TotalFarmersCovered, 0) * 1.0 / TotalPopulation
       END AS farmer_population_ratio
FROM data
WHERE TotalPopulation IS NOT NULL AND TotalPopulation > 0
ORDER BY farmer_population_ratio DESC
LIMIT 3;
-- Q13. Shorten state names by extracting their first three letters for readability or standardization.
--      for each unique state.
-- [2 Marks]
-- Approach: 
-- USING LEFT(srcStateName, 3) to extract characters
-- SELECT DISTINCT to avoid duplicates
-- ORDER BY srcStateName for alphabetical sorting
SELECT DISTINCT
    srcStateName,
    LEFT(srcStateName, 3) AS state_short_name
FROM data
ORDER BY srcStateName;
############################################################################################### #############################################################################
-- Q14. List districts beginning with the letter 'B' to understand naming patterns or filter specific regions.
-- [2 Marks]
-- Approach: 
-- USING LIKE 'B%' for pattern matching
-- SELECT DISTINCT to avoid duplicates
-- ORDER BY srcDistrictName for sorted output
SELECT DISTINCT srcDistrictName
FROM data
WHERE srcDistrictName LIKE 'B%'
ORDER BY srcDistrictName;
############################################################################################### #############################################################################
-- Q15. Identify districts ending with 'pur' to analyze zone naming conventions.
--      the word 'pur' at the end.
-- [2 Marks]
-- Approach: 
-- USING LIKE '%pur' for pattern matching
-- SELECT DISTINCT to avoid duplicates
-- ORDER BY srcStateName, srcDistrictName for organized output
SELECT DISTINCT srcStateName,
       srcDistrictName
FROM data
WHERE srcDistrictName LIKE '%pur'
ORDER BY srcStateName, srcDistrictName;
############################################################################################### #############################################################################
-- Q16. Calculate total premiums for districts having more than 10 insurance units using INNER JOIN approach.
--      Retrieve the aggregated FarmersPremiumAmount for districts where the district’s
--      Insurance units for an individual year are greater than 10.
-- [4 Marks]
-- Approach:
-- 1. Create a subquery (d1) to filter all rows where Insurance Units > 10.
-- 2. Use INNER JOIN to combine this with the main dataset (d2) on srcStateName, srcDistrictName, and srcYear.
-- 3. Group the joined data by state, district, and year to calculate yearly totals.
-- 4. Use SUM() to aggregate FarmersPremiumAmount per district per year.
-- 5. ORDER BY premium amount in descending order for ranking.
SELECT 
    d2.srcStateName AS state_name,
    d2.srcDistrictName AS district_name,
    d2.srcYear,
    SUM(d2.FarmersPremiumAmount) AS farmer_premium_sum
FROM (
    SELECT *
    FROM data
    WHERE `Insurance units` > 10
) AS d1
INNER JOIN data AS d2
    ON d1.srcStateName = d2.srcStateName
   AND d1.srcDistrictName = d2.srcDistrictName
   AND d1.srcYear = d2.srcYear
GROUP BY 
    d2.srcStateName, 
    d2.srcDistrictName, 
    d2.srcYear
ORDER BY 
    farmer_premium_sum DESC;
############################################################################################### #############################################################################

-- Q17. Report the districts where premium paid has ever exceeded 20 crores, showing max values and related stats.
--      for each district and the highest recorded FarmersPremiumAmount for that district
--      over all available years. Return only those districts where the highest
--      FarmersPremiumAmount exceeds 20 crores (200,000,000).
-- [5 Marks]

WITH max_premium_per_district AS (
    SELECT 
        srcStateName,
        srcDistrictName,
        MAX(FarmersPremiumAmount) AS max_district_premium
    FROM data
    GROUP BY srcStateName, srcDistrictName
)
SELECT
    d.srcStateName,
    d.srcDistrictName,
    d.Year,
    d.TotalPopulation,
    mp.max_district_premium
FROM data AS d
JOIN max_premium_per_district AS mp
    ON d.srcStateName = mp.srcStateName
   AND d.srcDistrictName = mp.srcDistrictName
WHERE mp.max_district_premium > 2000
  AND d.FarmersPremiumAmount = mp.max_district_premium
ORDER BY
    d.srcStateName,
    d.srcDistrictName,
    d.Year;

###-- Q18. Perform a LEFT JOIN to merge population and premium details for districts with high premium values.
--      data (TotalFarmersCovered, SumInsured) for each district and state.
--      Return the total premium amount (FarmersPremiumAmount) and the average population
--      count for each district aggregated over the years, where the total
--      FarmersPremiumAmount is greater than 100 crores (1,000,000,000).
--      Sort the results by total farmers' premium amount, highest first.
-- [5 Marks]
-- Approach: 
-- USING CTE farmer_premium_agg to compute SUM(FarmersPremiumAmount) per district
-- USING CTE population_avg to compute AVG(TotalPopulation) per district
-- LEFT JOIN farmer_premium_agg and population_avg on srcStateName and srcDistrictName
-- Filtering districts with WHERE total_farmers_premium > 10000  -- (10 000 lakhs = ₹100 crore)
-- ORDER BY total_farmers_premium DESC
WITH
  farmer_premium_agg AS (
    SELECT 
      srcStateName,
      srcDistrictName,
      SUM(FarmersPremiumAmount) AS total_farmers_premium
    FROM data
    GROUP BY srcStateName, srcDistrictName
  ),
  population_avg AS (
    SELECT 
      srcStateName,
      srcDistrictName,
      AVG(TotalPopulation) AS avg_district_population
    FROM data
    GROUP BY srcStateName, srcDistrictName
  )
SELECT
  f.srcStateName      AS state_name,
  f.srcDistrictName   AS district_name,
  f.total_farmers_premium,
  p.avg_district_population
FROM farmer_premium_agg AS f
LEFT JOIN population_avg AS p
  ON f.srcStateName     = p.srcStateName
 AND f.srcDistrictName  = p.srcDistrictName
WHERE f.total_farmers_premium > 10000   -- 10 000 lakhs = ₹ 100 crore
ORDER BY f.total_farmers_premium DESC;
############################################################################################### ###############################################################################################################################################################################3
-- SECTION 7.
-- Subqueries [10 Marks]
-- Q19. List districts where farmer coverage exceeds the overall dataset's average.
--      is greater than the average TotalFarmersCovered across all records.
-- [2 Marks]
-- Approach: 
-- USING a subquery to calculate AVG(TotalFarmersCovered)
-- Filtering districts with WHERE
-- SELECT DISTINCT to avoid duplicates
-- ORDER BY srcDistrictName
SELECT DISTINCT srcDistrictName
FROM data
WHERE TotalFarmersCovered > (SELECT AVG(TotalFarmersCovered) FROM data)
ORDER BY srcDistrictName;
############################################################################################### ###############################################################################################################################################################################
############################################################################################# #############################################################################
-- Q20. Write a query to find the srcStateName where the SumInsured is higher than 
--      the SumInsured of the district with the highest FarmersPremiumAmount.
-- [3 Marks]

-- Approach:
-- 1. Aggregate total SumInsured for each state using GROUP BY.
-- 2. Use a subquery to fetch the SumInsured of the district with the highest FarmersPremiumAmount.
-- 3. Apply HAVING to compare the aggregated SumInsured with the subquery result.
-- 4. Use ORDER BY to sort states by total_sum_insured in descending order.

SELECT 
    srcStateName,
    SUM(SumInsured) AS total_sum_insured
FROM data
GROUP BY srcStateName
HAVING total_sum_insured > (
    SELECT SumInsured
    FROM data
    ORDER BY FarmersPremiumAmount DESC
    LIMIT 1
)
ORDER BY total_sum_insured DESC;
############################################################################################### #############################################################################
-- Q21. Write a query to find the srcDistrictName where the FarmersPremiumAmount is higher than 
--      the average FarmersPremiumAmount of the state that has the highest TotalPopulation.
-- [5 Marks]

WITH state_population AS (
    -- Find the state with highest total population
    SELECT 
        srcStateName,
        SUM(TotalPopulation) as total_state_population
    FROM data
    WHERE TotalPopulation > 0  -- Filter out invalid population data
    GROUP BY srcStateName
    ORDER BY total_state_population DESC
    LIMIT 1
),
state_avg_premium AS (
    -- Calculate average premium for the highest population state
    SELECT 
        AVG(FarmersPremiumAmount) as avg_state_premium
    FROM data d
    INNER JOIN state_population sp 
        ON d.srcStateName = sp.srcStateName
    WHERE FarmersPremiumAmount > 0  -- Filter out zero or negative premiums
),
district_premiums AS (
    -- Get districts with premiums higher than state average
    SELECT 
        d.srcStateName,
        d.srcDistrictName,
        d.FarmersPremiumAmount,
        d.TotalFarmersCovered,
        d.SumInsured,
        ROUND((d.FarmersPremiumAmount / sap.avg_state_premium) * 100, 2) as premium_percentage
    FROM data d
    CROSS JOIN state_avg_premium sap
    WHERE d.FarmersPremiumAmount > sap.avg_state_premium
)
SELECT 
    srcStateName as state_name,
    srcDistrictName as district_name,
    FarmersPremiumAmount as premium_amount,
    TotalFarmersCovered as farmers_covered,
    SumInsured as total_insured,
    premium_percentage,
    CASE 
        WHEN premium_percentage > 200 THEN 'Very High'
        WHEN premium_percentage > 150 THEN 'High'
        WHEN premium_percentage > 120 THEN 'Above Average'
        ELSE 'Slightly Above Average'
    END as premium_category
FROM district_premiums
ORDER BY 
    premium_percentage DESC,
    FarmersPremiumAmount DESC;
############################################################################################### #############################################################################
-- Advanced SQL Functions (Window Functions) [10 marks]
############################################################################################### #############################################################################
-- Q22. Apply row numbering by descending farmer coverage to track relative ranking of entries.
--      ordered by total farmers covered in descending order.
-- [3 Marks]

-- Approach:
-- Use the ROW_NUMBER() window function to assign a unique rank to each record.
-- Order the rows by TotalFarmersCovered in descending order, so the highest gets rank 1.
-- Select all columns to keep the full context of each record.
SELECT *, ROW_NUMBER() OVER (ORDER BY TotalFarmersCovered DESC) AS rn
FROM data;
############################################################################################### #############################################################################
-- Q23. Rank districts within each state by their insured amount, descending, using windowing logic.
--      SumInsured (descending) and partition by alphabetical srcStateName.
-- [3 Marks]
-- Use the RANK() window function to assign ranks within each state.
-- Partition by srcStateName to group rankings by state.
-- Order by SumInsured in descending order so districts with higher insurance rank first.
SELECT *, RANK() OVER (PARTITION BY srcStateName ORDER BY SumInsured DESC) AS district_rank
FROM data;
############################################################################################### #############################################################################
-- Q24. Show cumulative premiums paid per district, ordered chronologically, to see growth over years.
--      for each district (srcDistrictName), ordered ascending by the srcYear, partitioned
--      by srcStateName.
-- [4 Marks]
-- Approach:
-- Use the SUM() window function to calculate a running total of FarmersPremiumAmount.
-- Partition the data by state and district to isolate each region.
-- Order by srcYear in ascending order to track cumulative growth over time.
SELECT *,
       SUM(COALESCE(FarmersPremiumAmount, 0)) OVER (
           PARTITION BY srcStateName, srcDistrictName
           ORDER BY RIGHT(Year, 4) ASC, rowID ASC
           ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
       ) AS CumulativeFarmersPremium
FROM data
WHERE Year IS NOT NULL;

############################################################################################### #############################################################################
-- SECTION 9.
-- Data Integrity (Constraints, Foreign Keys) [4 Marks]

-- Q25. Create foundational 'states' and 'districts' tables with appropriate primary key constraints.
--      DistrictName and StateCode. Create another table 'states' with StateCode as
--      primary key and column for StateName.
-- [2 Marks]
-- Approach: 
CREATE TABLE IF NOT EXISTS states (
    StateCode INT PRIMARY KEY,
    StateName VARCHAR(255)
);
CREATE TABLE IF NOT EXISTS districts (
    DistrictCode INT PRIMARY KEY,
    DistrictName VARCHAR(255),
    StateCode INT
);

############################################################################################### #############################################################################
-- Q26. Enforce relational integrity by linking district data to its parent state using foreign key constraints.
--      column from a states table.
-- [2 Marks]
-- Approach:
SELECT CONSTRAINT_NAME
FROM information_schema.KEY_COLUMN_USAGE
WHERE TABLE_NAME = 'districts'
  AND REFERENCED_TABLE_NAME = 'states'
  AND TABLE_SCHEMA = DATABASE();
############################################################################################### #############################################################################
-- SECTION 10.
-- UPDATE and DELETE [6 Marks]
-- Q27. Update a specific row's premium amount to demonstrate data modification with key-based targeting.
-- [2 Marks]
-- Approach: 
SET SQL_SAFE_UPDATES = 0;
UPDATE data
SET FarmersPremiumAmount = 500.0
WHERE rowID = 1;
SET SQL_SAFE_UPDATES = 1;
############################################################################################### #############################################################################
-- Q28. Update the policy year for all records of Himachal Pradesh to 2021 as part of data correction.
-- [2 Marks]
-- Use an UPDATE statement with a WHERE clause targeting the state name.
-- This ensures only records related to 'HIMACHAL PRADESH' are modified.
-- Useful for correcting misentered or outdated year values in bulk.
SET SQL_SAFE_UPDATES = 0;
UPDATE data
SET Year = 2021
WHERE srcStateName = 'HIMACHAL PRADESH';
SET SQL_SAFE_UPDATES = 1;
############################################################################################### #############################################################################
-- Q29. Delete records from the year 2020 where farmer coverage was below 10,000
-- Approach:
-- Use DELETE with a WHERE clause to target only 2020 records that meet the low coverage condition.
-- This cleans the dataset by removing underreported or insignificant entries.
-- It ensures data reflects meaningful farmer participation for that year.
SET SQL_SAFE_UPDATES = 0;
DELETE FROM data
WHERE TotalFarmersCovered < 10000 AND Year = 2020;
SET SQL_SAFE_UPDATES = 1;
############################################################################################### #############################################################################
############################################################################################### #############################################################################
