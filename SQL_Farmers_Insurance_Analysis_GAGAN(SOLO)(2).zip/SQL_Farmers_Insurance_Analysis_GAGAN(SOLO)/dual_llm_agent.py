from typing import Dict, List, Optional
from pydantic import BaseModel
from langchain_openai import ChatOpenAI
from langchain.prompts import ChatPromptTemplate
from langchain.schema import HumanMessage, SystemMessage
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

class CodeDraft(BaseModel):
    """Model for code draft with metadata"""
    code: str
    language: str
    description: str
    requirements: List[str]

class CodeReview(BaseModel):
    """Model for code review with feedback"""
    original_code: str
    improved_code: str
    suggestions: List[str]
    improvements_made: List[str]

class CodeDraftingLLM:
    """First LLM responsible for drafting code"""
    def __init__(self, model_name: str = "gpt-4-turbo-preview"):
        self.llm = ChatOpenAI(model_name=model_name, temperature=0.7)
        self.system_prompt = """You are an expert code drafter. Your task is to:
        1. Understand the requirements
        2. Generate clean, efficient, and well-documented code
        3. Follow best practices for the specified programming language
        4. Include necessary imports and dependencies
        5. Add appropriate comments and documentation"""
        
    def draft_code(self, requirements: str, language: str) -> CodeDraft:
        prompt = ChatPromptTemplate.from_messages([
            SystemMessage(content=self.system_prompt),
            HumanMessage(content=f"Please generate code in {language} for the following requirements:\n{requirements}")
        ])
        
        response = self.llm.invoke(prompt)
        return CodeDraft(
            code=response.content,
            language=language,
            description=requirements,
            requirements=requirements.split('\n')
        )

class CodeReviewLLM:
    """Second LLM responsible for reviewing and improving code"""
    def __init__(self, model_name: str = "gpt-4-turbo-preview"):
        self.llm = ChatOpenAI(model_name=model_name, temperature=0.3)
        self.system_prompt = """You are an expert code reviewer. Your task is to:
        1. Review the provided code thoroughly
        2. Identify potential improvements and optimizations
        3. Suggest better practices and patterns
        4. Provide an improved version of the code
        5. Explain all changes and improvements made"""
        
    def review_code(self, code_draft: CodeDraft) -> CodeReview:
        prompt = ChatPromptTemplate.from_messages([
            SystemMessage(content=self.system_prompt),
            HumanMessage(content=f"Please review and improve the following {code_draft.language} code:\n\n{code_draft.code}")
        ])
        
        response = self.llm.invoke(prompt)
        
        # Parse the response to extract improvements and suggestions
        # This is a simplified version - you might want to enhance this parsing
        improvements = response.content.split('\n')
        
        return CodeReview(
            original_code=code_draft.code,
            improved_code=response.content,
            suggestions=improvements,
            improvements_made=improvements
        )

class DualLLMAgent:
    """Main agent that coordinates between the two LLMs"""
    def __init__(self):
        self.drafter = CodeDraftingLLM()
        self.reviewer = CodeReviewLLM()
    
    def process_request(self, requirements: str, language: str) -> Dict:
        # Step 1: Draft the code
        draft = self.drafter.draft_code(requirements, language)
        
        # Step 2: Review and improve the code
        review = self.reviewer.review_code(draft)
        
        return {
            "draft": draft.dict(),
            "review": review.dict()
        }

# Example usage
if __name__ == "__main__":
    # Make sure to set your OpenAI API key in .env file
    agent = DualLLMAgent()
    
    # Example requirements
    requirements = """
    Create a function that calculates the factorial of a number
    Include error handling for negative numbers
    Add docstring and type hints
    """
    
    result = agent.process_request(requirements, "python")
    print("Draft:", result["draft"]["code"])
    print("\nReview:", result["review"]["improved_code"]) 